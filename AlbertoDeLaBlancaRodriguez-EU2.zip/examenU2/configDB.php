<?php
    $DBHost = "172.21.0.2";
    $DBUser = "exam_u2";
    $DBPassword = "1234";
    $DBName = "exam_u2";
    $DBDriver = "mysql";
    $DBPort = "3306";
?>