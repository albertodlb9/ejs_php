<?php
    define("DB_SERVER","172.21.0.2");
    define("DB_USERNAME","biblioteca");
    define("DB_DATABASE","biblioteca");
    define("DB_PASSWORD","");
    define("DB_PORT","3306");
    define("DB_PREFIX",""); //prefijo para las tablas por si usamos la misma BD para varias aplicaciones
    define("DB_DRIVER","mysql");
?>