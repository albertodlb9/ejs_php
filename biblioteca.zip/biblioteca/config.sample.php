<?php
    define("DB_SERVER","");
    define("DB_USERNAME","");
    define("DB_DATABASE","");
    define("DB_PASSWORD","");
    define("DB_PORT","3306");
    define("DB_PREFIX",""); //prefijo para las tablas por si usamos la misma BD para varias aplicaciones
    define("DB_DRIVER","mysql");
?>