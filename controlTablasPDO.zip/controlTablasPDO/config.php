<?php
//Configuración de los parámetros de Sistema Gestor de Bases de datos

$DBHost ="172.21.0.2";
$DBUser ="alberto";
$DBPassword ="ronaldo_9";
$DBName ="alberto";
$DBPort ="3306";
$DBdriver ="mysql";

?>
